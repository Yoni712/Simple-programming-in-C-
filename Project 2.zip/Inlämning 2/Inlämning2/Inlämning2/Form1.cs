using System.Windows.Forms;

namespace Inlämning2
{
    public partial class Form1 : Form
    {
        //Här har vi lite globala variabler och arrays som vi kommer att senare använda. 
        string[] namn = new string[100]; 
        string[] distrikt = new string[100];
        int[] persn = new int[100];
        int[] antal = new int[100];
        int antalInformation = 0, antalNivå1 = 0, antalNivå2 = 0, antalNivå3 = 0, antalNivå4 = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //Funktionen Lista används för att skriva ut namn, personnummer, distrikt och antal som var i fylld.
        public class Lista
        {
            public string Namn { get; set; }
            public int Persn { get; set; }
            public string Distrikt { get; set; }
            public int Antal { get; set; }


            public Lista(string namn, int persn, string distrik, int antal)
            {
                Namn = namn;
                Persn = persn;
                Distrikt = distrik;
                Antal = antal;
            }

            
            public override string ToString()
            {
                return $"* {Namn}, {Persn}, {Distrikt}, {Antal}";
            }
        }

        //Denna funktion gör samma sak som Lista, men används för att skriva ut "Namn, Personnummer, Distrikt, Antal" längst upp.
        //Detta är kanske lite överdrivet att göra allt det här för att skriva ut lite text högst upp. Men det var smidigt för mig
        //eftersom det bara krävdes att kopiera och klistra in tidigare funktion. 
        public class Lista1
        {
            public string Namn { get; set; }
            public string Persn { get; set; }
            public string Distrikt { get; set; }
            public string Antal { get; set; }


            public Lista1(string namn, string persn, string distrik, string antal)
            {
                Namn = namn;
                Persn = persn;
                Distrikt = distrik;
                Antal = antal;
            }

            
            public override string ToString()
            {
                return $"{Namn}, {Persn}, {Distrikt}, {Antal}";
            }
        }

        //Denna funktion skriver ut informationen i en text file. Detta händer när knappen "Click Me" är ner tryckt.   
        private void button3_Click(object sender, EventArgs e)
        {   
            //Här sätter vi namnet på filen.
            string fileName = "Information.txt";

            //Här använder vi StreamWrite för att skriva text till filen.
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                //Här går den igenom varje "item" i textboxen som heter "Information"
                foreach (var item in Information.Items)
                {
                    //writeLine skriver in varje item från textboxen i string form till filen.
                    writer.WriteLine(item.ToString());
                }
            }
            //Här har jag lagt en messagebox som dycker up när information har lyckats sparas i en fil. 
            MessageBox.Show(string.Format("Informationen har sparats i en text format med namnet {0}", fileName));
        }

        //Denna funcktion aktiveras när "Skicka" knappen är ner tryckt.
        //Den sparar all information i de globala arrayen vi skpade högst up.
        //Den även ser till att alla box är ifyllda innan man sparar informationen.  
        private void button1_Click(object sender, EventArgs e)
        {
            //Här är en if sats som kollar om texten i textbox1 inte är tom så
            //sparar den texten i string arreyen "namn" som vi skappade högst up. 
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                namn[antalInformation] = textBox1.Text;
            }
            //Om den är tom så får användaren ett fel meddelande.
            else
            {
                MessageBox.Show("Inte ifylld namn");
            }
            //Denna if-sats gör samma sak som den tidigare men den kollar även om
            //det som är ner skrivet är nummer och inte text med hjälp av "TryParse".
            if (!string.IsNullOrEmpty(textBox2.Text) && int.TryParse(textBox2.Text, out int personnummer))
            {
                persn[antalInformation] = int.Parse(textBox2.Text);
            }
            else
            {
                MessageBox.Show("Inte ifylld eller orimligt personnummer.");
            }

            if (!string.IsNullOrEmpty(textBox3.Text))
            {
                distrikt[antalInformation] = textBox3.Text;
            }
            else
            {
                MessageBox.Show("Inte ifylld distrikt.");
            }

            if (!string.IsNullOrEmpty(textBox4.Text) && int.TryParse(textBox4.Text, out int antalValue))
            {
                antal[antalInformation] = int.Parse(textBox4.Text);
            }
            else
            {
                MessageBox.Show("Inte ifylld eller orimligt antal.");
            }
            //här tar vi bort all text som var skriven i textboxarna. Detta är så att man
            //kan skriva in ny information efter att man har tryckt på "Skicka" knappen.
            if (!string.IsNullOrEmpty(textBox1.Text) && !string.IsNullOrEmpty(textBox2.Text) && !string.IsNullOrEmpty(textBox3.Text) && !string.IsNullOrEmpty(textBox4.Text))
            {
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                antalInformation++;
            }
            
            
        }

        //Denna function aktiveras när man trycker på "Visa Information".
        //Den kommer att printa ut alla information som har sparats. Detta kommer att göras med hjälp av funktionen "Lista". 
        private void button2_Click(object sender, EventArgs e)
        {
            //Först vi tar bort all text från textboxen ifall det fanns text från tidigare application. 
            Information.Items.Clear();

            //Vi lägger till Namn, Personnummer, Distrikt och Antal högst upp i listan. 
            Information.Items.Add(new Lista1("Namn", "Personnummer", "Distrikt", "Antal"));
            Information.Items.Add("");//Detta är för att ha lite mellanrum.

            //Vi nollställer alla nivåer här, annars kommer värderna på nivåerna från
            //tidigare application att läggas till med de nya.
            antalNivå1 = 0; antalNivå2 = 0; antalNivå3 = 0; antalNivå4 = 0;

            //Här skriver vi ut all information som har mindre än 50 på "antal".
            for (int i = 0; i < antalInformation; i++)
            {
                
                if (antal[i] < 50)
                {
                    Information.Items.Add(new Lista(namn[i], persn[i], distrikt[i], antal[i]));
                    //Vi adderar med 1 till anatalNivå1 varje gång anatal är mindre än 50 så att
                    //vi håller koll på antal listor som är i nivå 1. 
                    antalNivå1++;
                }

            }
            //Här skriver vi ut anatal säljare som är i nivå 1. Detta sker bara om det finns säljare med nivå 1. 
            if (antalNivå1 > 0)
            {
                Information.Items.Add(string.Format("{0} säljare har nått nivå 1: Under 50 sålda artiklar\n", antalNivå1));
                Information.Items.Add("");
            }
            
            //Samma som tidigare fast med nivå 2.
            for (int i = 0; i < antalInformation; i++)
            {
                
                if (antal[i] < 99 && antal[i] > 50)
                {
                    Information.Items.Add(new Lista(namn[i], persn[i], distrikt[i], antal[i]));
                    antalNivå2++;
                }
                
            }

            if (antalNivå2 > 0)
            {
                Information.Items.Add(string.Format("{0} säljare har nått nivå 2: Mellan 50-99 sålda artiklar\n", antalNivå2));
                Information.Items.Add("");
            }
                

            for (int i = 0; i < antalInformation; i++)
            {

                if (antal[i] < 199 && antal[i] > 100)
                {
                    Information.Items.Add(new Lista(namn[i], persn[i], distrikt[i], antal[i]));
                    antalNivå3++;
                }

            }

            if (antalNivå3 > 0)
            {
                Information.Items.Add(string.Format("{0} säljare har nått nivå 3: Mellan 100-199 sålda artiklar\n\n", antalNivå3));
                Information.Items.Add("");
            }
                

            for (int i = 0; i < antalInformation; i++)
            {

                if (antal[i] > 199)
                {
                    Information.Items.Add(new Lista(namn[i], persn[i], distrikt[i], antal[i]));
                    antalNivå4++;
                }

            }

            if (antalNivå4 > 0)
            {
                Information.Items.Add(string.Format("{0} säljare har nått nivå 4: Över 199 sålda artiklar\n\n", antalNivå4));
                Information.Items.Add("");
            }
                
        }
    }
}