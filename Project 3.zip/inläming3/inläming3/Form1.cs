﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace inläming3
{
    public partial class Form1 : Form
    {
        //strings för varje textbox
        string namn, efternamn, personnummer;
        
        public Form1()
        {
            
            InitializeComponent();
        }
        //klassen person så som i instruktionen. 
        public class Person
        {
            public string Förnamn { get; set; }
            public string Efternamn { get; set; }
            public string Personnummer { get; set; }

            public Person(string förnamn, string efternamn, string personnummer)
            {
                Förnamn = förnamn;
                Efternamn = efternamn;
                Personnummer = personnummer;
            }

            public override string ToString()
            {
                return $"{Förnamn} - {Efternamn} - ({Personnummer})";
            }
        }

        //"Avsluta" knappen. 
        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Detta är vad som sker om man trycker på "Kontroll" knappen.
        private void button3_Click(object sender, EventArgs e)
        {
            int nummer = 0;
            //Denna for loop kommer att gå igenom varje siffra genom att gå igenom varje postion av string "personnummer"
            for (int i = 0; i < personnummer.Length; i++)
            {                
                if (i % 2 == 0)//Detta kollar om i är jämn eller inte. För då kan man gångra siffran i personnummer med 2.
                {
                    if((int.Parse(personnummer[i].ToString()) * 2) < 10)//Här kollar vi om siffran är under 10, för då kan man bara
                                                                        //addera siffran till de totala mängden.
                    {
                        nummer += (int.Parse(personnummer[i].ToString()) * 2);
                    }                    
                    else   // Om siffran blir över 9 då vill vi addera siffrorna ihop. T.ex. 14 då blir det 1 + 4 = 5.
                    {
                        int tal = (int.Parse(personnummer[i].ToString()) * 2); // Här sparar vi siffran i ett int.
                        int summa;
                        summa = (tal % 10) + 1; //Från (nummer % 10) får vi ut sista siffran. Detta är genom att dela nummret
                                                   //med 10 och få resternade. Sedan adderar vi 1 för vi vet att största nummert
                                                   //vi kan få är 18 då 9*2 = 18.
                        nummer += summa; //Här adderar vi till talet till den totala mängden.

                    }
                }
                //Om i är ojämn så går den in hitt och lägger till siffran i personnummer till nummer. 
                else
                {
                    nummer += int.Parse(personnummer[i].ToString());
                }

                //Denna if sats kollar den nionde siffran i de 10 siffriga personnummer. Ifall den är jämn så är könen kvinna annars en man.
                if (i == 8)
                {
                    if(personnummer[i] % 2 == 0)
                    {
                        listBox1.Items.Add("Kön: Kvinna");
                    }
                    else
                    {
                        listBox1.Items.Add("Kön: Man");
                    }
                }
                                
            }
            //När vi har räknat ihop den totala mängde så kollar vi om den är fördelbar med 10 vilket är då ett rätt personnummer annars inte. 
            if (nummer % 10 == 0)
            {
                listBox1.Items.Add("Personnummer är rätt");
            }
            else
            {
                listBox1.Items.Add("Personnummer är inte rätt");
            }

        }

       
        //Detta är vad som sker när knappen "Registrera" trycks
        private void button2_Click(object sender, EventArgs e)
        {
            //Kollar igenom om alla textbox/luckor är ifyllda. Annars får man ett fel meddelande. Men om de är ifyllda så sparas de i respektiv string variabel.
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Fyll i namn.");
                }
                else
                {
                    namn = textBox1.Text;
                }

                if (string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    MessageBox.Show("Fyll i efternamn.");
                }
                else
                {
                    efternamn = textBox2.Text;
                }

                if (!string.IsNullOrEmpty(textBox3.Text))
                {
                    personnummer = textBox3.Text;
                }
                else
                {
                    MessageBox.Show("Fyll i personnummer.");
                }

            
                //Om alla textbox är ifyllda så töms de och skrivs ut i lisboxen. Vi använder även klassen person här för det.
            if(!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox3.Text))
            {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                Person person = new Person(namn, efternamn, personnummer);
                listBox1.Items.Clear();
                listBox1.Items.Add("Namn - Efternamn - Personnummer");
                listBox1.Items.Add(person);
            }

            

        }



    }
}
