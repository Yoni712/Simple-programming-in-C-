﻿// See https://aka.ms/new-console-template for more information

//Här frågar vi användaren att skriva in belopet.
Console.WriteLine("Ange belop: ");
string tempbelop = Console.ReadLine();
int belop = int.Parse(tempbelop);

//Hur mycket som betalades.
Console.WriteLine("Betalad: ");
string tempbetalat = Console.ReadLine();
int betalat = int.Parse(tempbetalat);

//Denna array använder jag till att spara antal "sedlar" av varje typ.
//Index 0 representerar 500 lap, index 1 200 lap osv. Så om två 500 lappar ska retuneras, så kommer elementet i indix 0 bli 2.
int[] amount = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

//Här ser vi till att det som betalades inte blir mindre än belopet som ska betalas.
if(betalat < belop)
{
    Console.WriteLine("Det du betalar är för lite");
    return;
}


//Här går vi in om det som betalas är mer än belopet. 
else
{
    //hur mycket man ska få tillbaks.
    int getBack = betalat - belop;

    //Denna loopen kör tills att det som man ska få tillbaks blir 0.
    while(getBack != 0)
    {
        //kollar om getBack är mer än 500. För om det stämmer, så ska man få tillbaks 500. 
        if(getBack >= 500)
        {
            //Då sparar vi infromationen i arrayen vi skapade tidigare.
            amount[0] = amount[0] + 1;
            //Det man får tillbaks blir nu minus 500.
            getBack = getBack - 500;
            
        }
        //samma som tidigare fast med 200.
        else if (getBack >= 200)
        {
            amount[1] = amount[1] + 1;
            getBack = getBack - 200;
            
        }

        else if (getBack >= 100)
        {
            amount[2] = amount[2] + 1;
            getBack = getBack - 100;
            
        }

        else if (getBack >= 50)
        {
            amount[3] = amount[3] + 1;
            getBack = getBack - 50;
            
        }

        else if (getBack >= 20)
        {
            amount[4] = amount[4] + 1;
            getBack = getBack - 20;
            
        }

        else if (getBack >= 10)
        {
            amount[5] = amount[5] + 1;
            getBack = getBack - 10;
            
        }

        else if (getBack >= 5)
        {
            amount[6] = amount[6] + 1;
            getBack = getBack - 5;
            
        }

        else if (getBack >= 2)
        {
            amount[7] = amount[7] + 1;
            getBack = getBack - 2;
            
        }

        else if (getBack >= 1)
        {
            amount[8] = amount[8] + 1;
            getBack = getBack - 1;
            
        }
    }
}

//Nu när vi vet hur mycket ska ska betalas tillbaks och sparat information i arrayen, så behöver vi skriva ut det.
//Vi vill ju inte skriva ut t.ex. "0 femhundralap". Vi vill ju bara skriva ut de vi ska få tillbaks, så därför kör vi med if sats för varje element i arreyen. 
if (amount[0] > 0)
{
    Console.Write("'{0}' femhundralap\n", amount[0]);
}

if(amount[1] > 0)
{
    Console.Write("'{0}' tvåhundralap\n", amount[1]);
}

if (amount[2] > 0)
{
    Console.Write("'{0}' hundralap\n", amount[2]);
}

if (amount[3] > 0)
{
    Console.Write("'{0}' femtiolap\n", amount[3]);
}

if (amount[4] > 0)
{
    Console.Write("'{0}' tjugolap\n", amount[4]);
}

if (amount[5] > 0)
{
    Console.Write("'{0}' tio kronor\n", amount[5]);
}

if (amount[6] > 0)
{
    Console.Write("'{0}' fem kronor\n", amount[6]);
}

if (amount[7] > 0)
{
    Console.Write("'{0}' två kronor\n", amount[7]);
}

if (amount[8] > 0)
{
    Console.Write("'{0}' en krona\n", amount[8]);
}