namespace PayBack_form_
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Detta �r vad som h�nder n�r knappen "Ber�kna" �r tryckt ner.
            
            string tempbelop = textBox1.Text; //H�r sparar vi informationen som var skriven i "Belop" 
            string tempbetalat = textBox2.Text; // H�r �r det f�r "Betalat"
            int belop = int.Parse(tempbelop); //Vi omvandlar stringen till integer s� att vi kan arbeta med siffror. 
            int betalat = int.Parse(tempbetalat); //samma

            //Nu n�r vi har f�tt Belop och Betalt, s� kan vi anv�nda exakt samma metod som i console applicationen, vilket vi g�r h�r nedan.
            int[] amount = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };

            if (betalat < belop)
            {
               MessageBox.Show("Du betalar f�r litte");
                return;
            }
            else
            {
                int getBack = betalat - belop;

                while (getBack != 0)
                {

                    if (getBack >= 500)
                    {
                        amount[0] = amount[0] + 1;
                        getBack = getBack - 500;

                    }

                    else if (getBack >= 200)
                    {
                        amount[1] = amount[1] + 1;
                        getBack = getBack - 200;

                    }

                    else if (getBack >= 100)
                    {
                        amount[2] = amount[2] + 1;
                        getBack = getBack - 100;

                    }

                    else if (getBack >= 50)
                    {
                        amount[3] = amount[3] + 1;
                        getBack = getBack - 50;

                    }

                    else if (getBack >= 20)
                    {
                        amount[4] = amount[4] + 1;
                        getBack = getBack - 20;

                    }

                    else if (getBack >= 10)
                    {
                        amount[5] = amount[5] + 1;
                        getBack = getBack - 10;

                    }

                    else if (getBack >= 5)
                    {
                        amount[6] = amount[6] + 1;
                        getBack = getBack - 5;

                    }

                    else if (getBack >= 2)
                    {
                        amount[7] = amount[7] + 1;
                        getBack = getBack - 2;

                    }

                    else if (getBack >= 1)
                    {
                        amount[8] = amount[8] + 1;
                        getBack = getBack - 1;

                    }
                }
            }

            // Example: Adding a list of results to the ListBox
            listBox1.Items.Clear();
            if (amount[0] > 0)
            {
                listBox1.Items.Add(string.Format("{0} femhundralap\n", amount[0]));
            }

            if (amount[1] > 0)
            {
                listBox1.Items.Add(string.Format("{0} tv�hundralap\n", amount[1]));
            }

            if (amount[2] > 0)
            {
                listBox1.Items.Add(string.Format("{0} hundralap\n", amount[2]));
            }

            if (amount[3] > 0)
            {
                listBox1.Items.Add(string.Format("{0} femtiolap\n", amount[3]));
            }

            if (amount[4] > 0)
            {
                listBox1.Items.Add(string.Format("{0} tjugolap\n", amount[4]));
            }

            if (amount[5] > 0)
            {
                listBox1.Items.Add(string.Format("{0} tio kronor\n", amount[5]));
            }

            if (amount[6] > 0)
            {
                listBox1.Items.Add(string.Format("{0} fem kronor\n", amount[6]));
            }

            if (amount[7] > 0)
            {
                listBox1.Items.Add(string.Format("{0} tv� kronor\n", amount[7]));
            }

            if (amount[8] > 0)
            {
                listBox1.Items.Add(string.Format("{0} krona\n", amount[8]));
            }


        }
    }
}